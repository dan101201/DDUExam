using UnityEngine.InputSystem;

internal partial class CoreTests : InputTestFixture
{
}
